#include <stdint.h>
#include "Nvic.h"
#include "Bit_Operations.h"

#define NVIC_BASE (0xE000E100)

// Define NVIC_ISER registers for the range 0 to 255 interrupts
#define NVIC_ISER0 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 0)))
#define NVIC_ISER1 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 1)))
#define NVIC_ISER2 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 2)))
#define NVIC_ISER3 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 3)))
#define NVIC_ISER4 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 4)))
#define NVIC_ISER5 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 5)))
#define NVIC_ISER6 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 6)))
#define NVIC_ISER7 (*(volatile uint32_t *)(NVIC_BASE + (0x04 * 7)))

// Define NVIC_ICER registers for the range 0 to 255 interrupts
#define NVIC_ICER0 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 0)))
#define NVIC_ICER1 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 1)))
#define NVIC_ICER2 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 2)))
#define NVIC_ICER3 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 3)))
#define NVIC_ICER4 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 4)))
#define NVIC_ICER5 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 5)))
#define NVIC_ICER6 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 6)))
#define NVIC_ICER7 (*(volatile uint32_t *)(NVIC_BASE + 0x80 + (0x04 * 7)))

void Nvic_EnableInterrupt(uint8_t IRQn) {
  // Array of pointers to NVIC_ISER registers
  volatile uint32_t *NVIC_ISER[] = {
    &NVIC_ISER0, &NVIC_ISER1, &NVIC_ISER2, &NVIC_ISER3,
    &NVIC_ISER4, &NVIC_ISER5, &NVIC_ISER6, &NVIC_ISER7
  };

  // Calculate the index for the NVIC_ISER array
  uint8_t index = IRQn / 32;

  // Calculate the bit position within the register
  uint8_t bit_position = IRQn % 32;

  // Set the appropriate bit in the NVIC_ISER register
  SET_BIT(*NVIC_ISER[index], bit_position);
}

void Nvic_DisableInterrupt(uint8_t IRQn) {
  // Array of pointers to NVIC_ICER registers
  volatile uint32_t *NVIC_ICER[] = {
    &NVIC_ICER0, &NVIC_ICER1, &NVIC_ICER2, &NVIC_ICER3,
    &NVIC_ICER4, &NVIC_ICER5, &NVIC_ICER6, &NVIC_ICER7
  };

  // Calculate the index for the NVIC_ICER array
  uint8_t index = IRQn / 32;

  // Calculate the bit position within the register
  uint8_t bit_position = IRQn % 32;

  // Set the appropriate bit in the NVIC_ICER register
  SET_BIT(*NVIC_ICER[index], bit_position);
}

// Variables to track LED state and button state
static uint8_t led_state = 0; // 0: OFF, 1: ON

// Function to initialize the LED (assuming a certain GPIO pin)
void LED_Init(void) {
  // Initialization code for the LED GPIO pin
  // For example, configure the pin as output
}

// Function to turn the LED on
void LED_On(void) {
  // Code to turn the LED on
  led_state = 1;
}

// Function to turn the LED off
void LED_Off(void) {
  // Code to turn the LED off
  led_state = 0;
}

// Function to toggle the LED state
void LED_Toggle(void) {
  if (led_state) {
    LED_Off();
  } else {
    LED_On();
  }
}

// Function to handle button press (assuming an interrupt triggers this function)
void Button_Handler(void) {
  // Toggle the LED state
  LED_Toggle();
}

// External interrupt handler for the button press
void EXTI0_IRQHandler(void) {
  // Call the button handler function
  Button_Handler();
}
